import os
from setuptools import setup
from nvpy import nvpy

setup(
    name = "TicTacToe",
    version = "1.0",
    author = "Vatsal Hariramani",
    author_email = "hariramaniv@gmail.com",
    description = "TicTacToe",
    license = "MIT",
    url = "https://github.com/VH-Tech/TicTacToe",
    packages=['TicTacToe'],
    entry_points = {
        'gui_scripts': ['TicTacToe=TicTacToe.TicTacToe:main']
    },
    data_files = [
        ('share/applications/', ['vxlabs-TicTacToe.desktop'])
    ],
    classifiers=[
        "License :: OSI Approved :: BSD License",
    ],
)